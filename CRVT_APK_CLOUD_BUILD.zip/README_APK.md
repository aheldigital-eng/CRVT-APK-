# CRVT — Projet APK

Base utilisée : CRVT_FINAL_SOIR.zip.
Le dossier `app/src/main/assets/` contient la copie de l'application web stable.
L'application Android l'ouvre localement dans un WebView, sans réécrire le code métier.

Objectif : produire une APK Android installable sur le téléphone professionnel.
